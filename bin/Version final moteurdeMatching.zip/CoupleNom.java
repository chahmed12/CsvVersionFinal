public class CoupleNom {
    private EntreeNom nom1;
    private EntreeNom nom2;
    public CoupleNom(EntreeNom nom1,EntreeNom nom2){
        this.nom1=nom1;
        this.nom2=nom2;
    }

    public EntreeNom getNom1(){
        return nom1;
    }
    public EntreeNom getNom2(){
        return nom2;
    }
    
    
    
}
