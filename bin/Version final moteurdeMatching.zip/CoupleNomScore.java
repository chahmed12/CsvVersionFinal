public class CoupleNomScore {
    private String nom1;
    private String nom2;
    private double score;
    public CoupleNomScore(String nom1,String nom2,double score){
        this.nom1=nom1;
        this.nom2=nom2;
        this.score=score;
    }
    public double getScore(){
        return score;
    }
    public String getNom11(){
        return nom1;
    }
    public String getNom22(){
        return nom2;
    }
}
