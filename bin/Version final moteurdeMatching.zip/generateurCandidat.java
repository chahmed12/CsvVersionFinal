import java.util.List;
public interface generateurCandidat {
    public List<CoupleNom> generer(List<EntreeNom> l1,List<EntreeNom> l2);
    
}
