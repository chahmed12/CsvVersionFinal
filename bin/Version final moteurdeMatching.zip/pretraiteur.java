import java.util.List;
public interface pretraiteur {
    public  List<String> traiter(List<String> L);
}
