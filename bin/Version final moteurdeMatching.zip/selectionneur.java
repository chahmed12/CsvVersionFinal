import java.util.List;
public interface selectionneur {
    public List<CoupleNomScore> selectionner(List<CoupleNomScore> candidats);
}
