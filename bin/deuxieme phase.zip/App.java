public class App {
    public static void main(String[] args) {
        recuperateurCsv r =new recuperateurCsv("C:/Users/lassa/Downloads/noms.csv");
        generateurCandidat g =new generateurSimple(r.recuperer());
        comparateurExact c=new comparateurExact();
        selectionneur s=new selectionneurSimple(1.0);
        pretraiteur p=new PretraiteurSimple();
        moteurdeRecherche m = new moteurdeRecherche(c,g,s,p);
        for (EntreeNom n : m.rechercher("wassim")) {
            System.out.println("- " + n.get_Nom());
        }

    }
}
