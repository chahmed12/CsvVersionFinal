public class CoupleNom {
    private String nom1;
    private String nom2;
    public CoupleNom(String nom1,String nom2){
        this.nom1=nom1;
        this.nom2=nom2;
    }
    
}
