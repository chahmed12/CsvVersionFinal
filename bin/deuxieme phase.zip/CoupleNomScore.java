public class CoupleNomScore {
    private String nom1;
    private String nom2;
    private double score;
    public CoupleNomScore(String nom1,String nom2,double score){
        this.nom1=nom1;
        this.nom2=nom2;
        this.score=score;
    }
}
