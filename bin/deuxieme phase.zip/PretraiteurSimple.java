public class PretraiteurSimple implements pretraiteur{
    
  public String traiter(String nom){
    return nom.toLowerCase();

  }
}
