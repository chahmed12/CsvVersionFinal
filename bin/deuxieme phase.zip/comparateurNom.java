public interface comparateurNom {
   public double comparer(EntreeNom nom1,EntreeNom nom2);
}
