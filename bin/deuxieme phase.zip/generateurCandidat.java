import java.util.List;
public interface generateurCandidat {
    List<EntreeNom> generer();
    
}
