import java.util.List;
public class generateurSimple implements generateurCandidat{
    private List<EntreeNom> base;

    public generateurSimple(List<EntreeNom> base) {
        this.base = base;
    }
    public List<EntreeNom> generer(){
        return base;
    }
}
