import java.util.ArrayList;
import java.util.List;

public class moteurdeRecherche {
    private comparateurNom comparateurNom;
    private generateurCandidat generateurCandidat;
    private selectionneur selectionneur;
    private pretraiteur pretraiteur;
    public moteurdeRecherche(comparateurNom comparateurNom,generateurCandidat generateurCandidat,selectionneur selectionneur,pretraiteur pretraiteur){
        this.comparateurNom = comparateurNom;
        this.generateurCandidat = generateurCandidat ;
        this.selectionneur = selectionneur ;
        this.pretraiteur=pretraiteur;

    }
    public List<EntreeNom> rechercher(String nom) {
        String nomTraite = pretraiteur.traiter(nom);
        EntreeNom nomrech =new EntreeNom(nomTraite);
        List<EntreeNom> candidats = generateurCandidat.generer();
        List<NomScore> scores = new ArrayList<>();

        for (EntreeNom candidat : candidats) {
            String nomCandidatTraite = pretraiteur.traiter(candidat.get_Nom());
            EntreeNom candidatTraite = new EntreeNom(nomCandidatTraite);
            double score = comparateurNom.comparer(nomrech,candidatTraite);
            scores.add(new NomScore(candidat, score));
        }

        return selectionneur.selectionner(scores); 
    }


    
    
}
