public interface pretraiteur {
    public  String traiter(String nom);
}
