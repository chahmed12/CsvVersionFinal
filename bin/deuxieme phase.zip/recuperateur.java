import java.util.List;

public interface recuperateur {
    List<EntreeNom> recuperer();
    
}
