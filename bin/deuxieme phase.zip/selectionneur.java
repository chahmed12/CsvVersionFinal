import java.util.List;
public interface selectionneur {
    public List<EntreeNom> selectionner(List<NomScore> candidats);
}
